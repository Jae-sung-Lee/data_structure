#include <iostream>
#include <optional>

template <typename T, typename U>
class BSNode{
    
    public :
        T key;
        U value;
        BSNode<T,U> * left;
        BSNode<T,U> * right;

        BSNode<T,U>(const T& k, const U& v)
        {
            key = k;
            value = v;
            left = nullptr;
            right = nullptr;
        }

};

template<typename T, typename U>
class BSTree {

    public : 
        BSNode<T,U> * root = nullptr;
        ~BSTree() {
            removeall(root);
        }

        bool insert(const T& key, const U& value);
        U search(const T& key);
        bool remove(const T& key);
        
        //for checking
        void preorder(BSNode<T,U>*& node){
            if(!node) return;

            std::cout<<node->key<<": "<<node->value<<std::endl;
            preorder(node->left);
            preorder(node->right);
        }
        void inorder(BSNode<T,U>*& node){
            if(!node) return;

            inorder(node->left);
            std::cout<<node->key<<": "<<node->value<<std::endl;
            inorder(node->right);
        }

    private :
        bool insert(BSNode<T,U>*& node, const T& key, const U& value);
        U search(BSNode<T,U>*& node, const T& key);
        BSNode<T,U>* remove(BSNode<T,U>*& node, const T& key);
        void removeall(BSNode<T,U>*& node);
};


template<typename T, typename U>
bool BSTree<T,U>::insert(const T& key, const U& value) {
    return insert(root, key, value);
}

template<typename T, typename U>
U BSTree<T,U>::search(const T& key) {
    return search(root, key);
}

template<typename T, typename U>
bool BSTree<T,U>::remove(const T& key) {
    if(!search(root,key)) return false;
    remove(root, key);
    return true;
}


template<typename T, typename U>
bool BSTree<T,U>::insert(BSNode<T,U>*& node, const T& key, const U& value) {
    //TODO
    

}

template<typename T, typename U>
U BSTree<T,U>::search(BSNode<T,U>*& node, const T& key) {
    //TODO
    

}

template<typename T, typename U>
BSNode<T,U>* BSTree<T,U>::remove(BSNode<T,U>*& node, const T& key) {
    //TODO
    

}

template<typename T, typename U>
void BSTree<T,U>::removeall(BSNode<T,U>*& node) {
    //TODO
   

}

